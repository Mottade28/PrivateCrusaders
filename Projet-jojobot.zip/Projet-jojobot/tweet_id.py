#A flouter  !!!!
consumer_key = "WA0l4Sy4MhHsVdBcmbnM7pN7x"
consumer_secret = 'Nh6mDtb1DswTKWr6ANRnM8JuEIakef4u3Qul1iVfmVnPXfiiTI'

access_token = '1426298446189891585-UStf8bdbFRwVsa93m86NvCj4H5VtdL'
access_secret = 'v3jm0lkWw4X6ZSAlABvx0KgmWfaAn4Nt2LqDwZlc7lBXk'
