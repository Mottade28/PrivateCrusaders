#Imports
import time, tweepy
from tweet_id import consumer_key, consumer_secret, access_token, access_secret


#Connect to API

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)
api = tweepy.API(auth)



LeTweet = "Salut la commu pt2"
api.update_status(status=LeTweet)




print("Connected to twitter API")







"""
list = []
with open('res/Jojo-text/Phantom-blood.txt', encoding="utf8") as f:
    list = f.readlines()

count = 0
for line in list:
    count += 1
    print(f'line {count}: {line}')    
   
"""







